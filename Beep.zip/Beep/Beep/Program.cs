﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.Collections.Generic;


namespace Beep
{
    class Program
    {
        static void Main()
        {
            const int dot = 128;
            const int dash= (dot*3);
            const int space = (dot * 7);
            string entrada;
            string traduccion = "";
            char[] abc = { ' ','A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
            string[] morseCode = {"    ", ". ___", "___ . . .", "___ . ___ .", "___ . .", ".", ". . ___ .", "___ ___ .", ". . . .", ". .", ". ___ ___ ___", "___ . ___", ". ___ . .", "___ ___", "___ .", "___ ___ ___", ". ___ ___ .", "___ ___ . ___", ". ___ .", ". . .", "_", ". . ___", ". . . ___", ". ___ ___", "___ . . ___", "___ . ___ ___", "___ ___ . .", ". ___ ___ ___ ___", ". . ___ ___ ___", ". . . ___ ___", ". . . . ___", ". . . . .", "___ . . . .", "___ ___ . . .", "___ ___ ___ . .", "___ ___ ___ ___ .", "___ ___ ___ ___ ___" };

            Console.WriteLine("De texto a codigo morse");
            entrada = Console.ReadLine();
            entrada.ToUpper();
            try
            {
                for (int i = 0; i < entrada.Length; i++)
                {
                    for (short j = 0; j < 37; j++)
                    {
                        if (entrada[i]== abc[j])
                        {
                            traduccion += morseCode[j];
                            traduccion += "|";
                            break;
                        }
                    }
                    foreach(var codigo in morseCode[i])
                    {
                        if (codigo == '.')
                        {
                            Console.Beep(600,dot);
                        }
                        else
                        {
                            Console.Beep(600, dash);
                        }
                        System.Threading.Thread.Sleep(dash);
                    }

                }
                Console.WriteLine("Texto traducido a Morse: ");
                Console.WriteLine(traduccion);
            }
            catch (Exception error)
            {
                Console.WriteLine("Error: ", error.Message);
                throw;
            }
            System.Threading.Thread.Sleep(space);
        }
    }
}
